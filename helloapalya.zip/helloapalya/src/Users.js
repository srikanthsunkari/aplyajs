import React, {Component} from 'react'

class Users extends Component{
    constructor(){
        super();

        this.state={
            users:[],
            isLoaded:false
        }
    }

    render(){
        return(
                (this.state.isLoaded) ?  
                    <div>
                        <h1>Users</h1>
                        <ul>
                        {
                            this.state.users.map((user)=>{
                                return <li key={user.id}>{user.name}</li>
                            })
                        }
                        </ul>
                    </div>
                :  
                    <div>Loading...</div>
        )
    }

    componentDidMount(){
        fetch('https://jsonplaceholder.typicode.com/users')
        .then(response=>response.json())
        .then((users)=>{
            this.setState({
                users:users,
                isLoaded:true
            })
        })
    }
}

export default Users;