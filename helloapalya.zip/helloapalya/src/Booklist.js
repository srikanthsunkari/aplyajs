import React, {Component} from 'react';
import Book from './Book'

class BookList extends Component{
    constructor(props){
        super(props);

        this.state={
            books:props.books
        }
    }

    componentWillReceiveProps(newProps){
        console.log(JSON.stringify(newProps))
        this.setState({
            books:newProps.books
        })
    }

    addBookToWishlist=(book)=>{
        console.log(JSON.stringify(book))
        this.props.updateWishlist(book)
    }

    render(){
        return(
            <div>
                {
                    this.state.books.map((book)=>{
                        return <Book key={book} book={book} addBookToWishlist={this.addBookToWishlist}/>
                    })
                }
            </div>
        )
    }
}

export default BookList;