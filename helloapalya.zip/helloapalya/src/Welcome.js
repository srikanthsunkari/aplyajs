import React, {Component} from 'react'
import PropTypes from 'prop-types';

class Welcome extends Component{
    constructor(){
        super();

        this.state={
            clicks:0
        }
    }

    updateClicks=()=>{
        this.setState({
            clicks:this.state.clicks+1
        })
    }

    render(){
        console.log("rendering again")
        return ( 
            <h1 className="heading" onClick={this.updateClicks}>Welcome to { this.props.text } ({this.state.clicks})</h1>
        )
    }
}

Welcome.propTypes={
    text:PropTypes.string.isRequired
}

Welcome.defaultProps={
    text:"Apalya"
}


export default Welcome;