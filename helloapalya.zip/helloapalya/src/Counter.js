import React, { Component } from 'react'

class Counter extends Component {
    constructor(){
        super();

        this.state={
            count:0,
            isDisabled:true
        }
    }

    increment=()=>{
        this.setState({
            count:this.state.count+1,
            isDisabled:false
        })
    }

    decrement=()=>{
        if(this.state.count==0){
            this.setState({
                isDisabled:true
            })
        }
        else
        {
            this.setState({
                count:this.state.count-1,
                isDisabled:false
            })
        }
    }

    render() {
        return (
            <div>
                <h1>Counter</h1>
                <p>{this.state.count}</p>
                <button onClick={this.increment}>Increment</button>
                <button onClick={this.decrement} disabled={this.state.isDisabled}>Decrement</button>
            </div>
        )
    }
}

export default Counter;