import React, {Component} from 'react';

class Book extends Component{
    constructor(props){
        super(props);
        this.state={
            book:props.book
        }
    }

    addToWishlist=()=>{
        this.props.addBookToWishlist(this.state.book)
    }

    render(){
        return(
            <div>
               <h3>{this.state.book.name}</h3>
               <button onClick={this.addToWishlist}>Add to wishlist</button>
            </div>
        )
    }
}

export default Book;