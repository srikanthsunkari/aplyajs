import React, {Component} from 'react';
import BookList from './Booklist'
import axios from 'axios'

class Library extends Component{
    constructor(){
        super();
        this.state={
            books:[],
            wishlist:[]
        }
    }

    getBooks=()=>{
        axios('https://jsonplaceholder.typicode.com/users')
        .then((results)=>{
            //console.log(JSON.stringify(results.data))
            this.setState({
                books:results.data
            })
        })
    }

    componentDidMount(){
        this.getBooks()
    }

    updateWishlist=(book)=>{
        console.log(JSON.stringify(book))
        this.setState({
            wishlist:[
                ...this.state.wishlist,
                book
            ]
        })
    }

    render(){
        return(
            <div>
                <h1>Library</h1>
                <p>My wishlist : {this.state.wishlist.length}</p>
                <BookList books={this.state.books} updateWishlist={this.updateWishlist}/>
            </div>
        )
    }
}

export default Library;