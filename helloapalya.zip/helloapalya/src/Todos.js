import React, {Component} from 'react'

const Todo=(props)=>{
    return <li>{props.text}</li>
}

class Todos extends Component{
    constructor(){
        super();

        this.state={
            todos:[],
            todo:''
        }
    }

    onTodoChange=(e)=>{
        var todo=e.target.value;
        this.setState({
            todo
        })
    }

    addTodo=()=>{
        this.setState({
            todos:[...this.state.todos,this.state.todo]
        },()=>{
            this.setState({
                todo:''
            })
        })
    }

    render(){
        return(
            <div>
                <h1>Todos</h1>
                <input type="text" name="todo" value={this.state.todo} onChange={this.onTodoChange}/>
                <button onClick={this.addTodo}>Add Todo</button>
                <ul>
                {
                    this.state.todos.map((todo)=>{
                        return <Todo key={todo} text={todo}/>
                    })
                }
                </ul>
            </div>
        )
    }
}

export default Todos;