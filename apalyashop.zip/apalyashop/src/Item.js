import React, {Component} from 'react'

class Item extends Component{
    render(){
        return(
            <div>
                <b>{this.props.item.itemName}</b>
                <p>Price:{this.props.item.price}</p>
                {
                    (!this.props.isCart) ? <button onClick={()=>this.props.addItemToCart(this.props.item)}>Add To Cart</button> 
                                        : <button onClick={()=>this.props.removeFromCart(this.props.item)}>Remove</button>
                }
                { (this.props.isCart) ? <p>Qty:{this.props.item.qty}</p> : "" }
            </div>
        )
    }
}

export default Item;